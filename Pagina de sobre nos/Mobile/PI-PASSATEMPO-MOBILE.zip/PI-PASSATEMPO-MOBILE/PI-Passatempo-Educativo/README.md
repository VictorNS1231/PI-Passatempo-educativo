# PI-Passatempo-Educativo
Projeto Integrador 2 semestre - Desenvolvimento de um site para a instituição Passatempo Educativo - HTML/CSS/JS
